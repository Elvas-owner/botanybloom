package com.example.botanybloom

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Patterns
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.example.botanybloom.LoginActivity

class RegisterActivity : Activity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val register_button = findViewById<Button>(R.id.btn_register)
        val et_firstname = findViewById<EditText>(R.id.firstname)
        val et_lastname = findViewById<EditText>(R.id.lastname)
        val et_email = findViewById<EditText>(R.id.et_email)
        val et_registerpass = findViewById<EditText>(R.id.et_password)
        val sharedPreferences: SharedPreferences = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)

        register_button.setOnClickListener {
            val firstname = et_firstname.text.toString().trim()
            val lastname = et_lastname.text.toString().trim()
            val email = et_email.text.toString().trim() // Treating as email
            val password = et_registerpass.text.toString().trim()

            if (firstname.isEmpty()) {
                showToast("First name is required!")
            } else if (lastname.isEmpty()) {
                showToast("Last name is required!")
            } else if (email.isEmpty()) {
                showToast("Email is required!")
            } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                showToast("Enter a valid email address!")
            } else if (password.isEmpty()) {
                showToast("Password is required!")
            } else if (!isValidPassword(password)) {
                showToast("Password must be at least 8 characters long, contain at least one letter, one number, and one special character.")
            } else if (sharedPreferences.contains("username_$email")) {
                showToast("Email is already registered!")
            } else {
                // Save user data
                val editor = sharedPreferences.edit()
                editor.putString("fullName_$email", "$firstname $lastname")
                editor.putString("username_$email", email) // Still using username variable
                editor.putString("email_$email", email) // Storing as email
                editor.putString("password_$password", password)
                editor.putString("loggedInUser", email) // Store the logged-in user
                editor.apply()

                showToast("Registration successful!")

                val intent = Intent(this, LoginActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
            }
        }
    }

    // Function to check if password meets the required criteria
    private fun isValidPassword(password: String): Boolean {
        val passwordPattern = "^(?=.*[A-Za-z])(?=.*\\d)(?=.*[^A-Za-z\\d])[A-Za-z\\d\\S]{8,}$"
        return password.matches(passwordPattern.toRegex())
    }

    // Function to show toast messages
    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}